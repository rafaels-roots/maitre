<!DOCTYPE html>
<html>
    <head>
        <title>Not Found</title>    
		
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
	
    </head>
    <body>
   
		<h1 style="font-family:Segoe UI;">Ops! Mobile</h1>   

	</body>

</html>
